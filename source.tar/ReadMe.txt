Adapter Haas_linux 2.2

Postup pro nasazeni:

- v serial.unix.inc nutno zmenit cestu pro socat k prevodniku Ethernet/RS232 a zmenit cestu k vytvoreni virtualniho portu vcom0 pro nastaveni chmod666 (napr. /home/vtech/vcom0 )
- v supervisoru je nutne spustit proces s parametrem -p /home/vtech/vcom0 (realne umisteni virtualniho portu)
- defaultne je port adapteru nastaven na 7878

Upravy:

31.5.2022
1) pridani tridy k pripojeni na ethernet = preruseno pac starsi systemy neumeji Q codes po ethernetu
2) pridany vlakna, kde lze pouzit max. 2 vlakna = tj. 2 seriove porty

2.6.2022
1) dodelat ukonceni serveru pri ukonceni adapteru, pac se to kousne, urcite tam bude muset byt pthread_join a pak ukonceni vlaken a zniceni serveru => 
startServer() musi dojit na konec, aby pthread_join ve fci stopMichalServer() dosla na konec => asi vyreseni, dal jsem
destruktor mServer do destruktoru adapteru

4.2.2023
verze Adapter haas linux evo2.1
1) pridani funkci mProgramToFile() a mProgramToRead() pro nacitani cisla programu, pokud vypadne pripojeni k ethernetu a stroj je v rezimu automatic (busy)

6.2.2023
1) obcas spadne program pri zmene config souboru => presunul jsem destruktor serveru z stopMichalServer do destruktoru adapter

10.2.2023
1) upravena fce kontrola_zmeny_seznamu_adapteru(), kdy php script vytvari config_json => zrusen exit() pokud obsah souboru je 0. Inkrementuje pocet pokusu

20.2.2023
1) pridano jmeno CESTA_mPROGRAM zalozniho jmena souboru pro nacitani cisla programu. Zadana pevna cesta

28.2.2023
1) pridano strlen(buff)+1, pac samotne strlen(buff) orizlo ukoncovaci nulu

1.3.2023
1) v server.cpp odkomentovano bool added
2) pridana kontrola ve funkcich mProgramToFile mProgramToRead

10.3.2023
1) v haas_serial.cpp nalezena chyba v getVariable(), kdy  v if (atoi(ret->at(1).c_str()) == aVariableNumber) { v tele ifu chybel again = false}, to melo za nasledek, kdyz se pri 
reset tlacitka ve stroji Haas prerusila komunikace, tak tam skocilo again = true a pak to nemohlo opustit smycku do -> while


19.5.2025
1) nova verze 2.2
2) pridani fci   
    void startMichalServer();
    void stopMichalServer();
    static void* thread_server(void* param);
do tridy HaasAdapter z tridy Adapter, protoze v predku Adapter nebyla dostupna nejaka data z konstruktoru HaasAdapter a pri zmene konfiguracniho souboru program spadl,
protoze data nebyla dostupna.


============== Navrhy na zlepseni =====================

pridat kontrolu otevreni souboru mProgram7878.txt, pokud program spustim a stroj je v rezimu automatic, active (busy) a ve slozce neni soubor mProgram7878.txt, tak to spadne
pridat kontrolu na fopen()
prazdna funkce MTCautolock :: lock() - nutno pridat linuxovej mutex

