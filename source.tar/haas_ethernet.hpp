
#ifndef HAAS_ETHERNET
#define HAAS_ETHERNET

#include <vector>
#include <string>
#include <iostream>
#include <pty.h>

class HaasEthernet
{
public:
  std::string _Device;
  std::string _IP_addr;
  int _port;
  int _socket;
  sockaddr_in _server;
  bool _connected = false;

  HaasEthernet(const char *aDevice, const char *IP_addr,int port);
  int connect_ethernet();
  int close_ethernet();
  int sendCommand(const char *aCommand,std::vector<std::string>** vecOut);
  bool getVariable(int aVariableNumber, double &aResult);

protected:
  std::vector<std::string> *split(const char *aString);
};

#endif
