make dep
make
./aplikace_mon_prac

