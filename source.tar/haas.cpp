/*
* Copyright (c) 2008, AMT – The Association For Manufacturing Technology (“AMT”)
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*     * Redistributions of source code must retain the above copyright
*       notice, this list of conditions and the following disclaimer.
*     * Redistributions in binary form must reproduce the above copyright
*       notice, this list of conditions and the following disclaimer in the
*       documentation and/or other materials provided with the distribution.
*     * Neither the name of the AMT nor the
*       names of its contributors may be used to endorse or promote products
*       derived from this software without specific prior written permission.
*
* DISCLAIMER OF WARRANTY. ALL MTCONNECT MATERIALS AND SPECIFICATIONS PROVIDED
* BY AMT, MTCONNECT OR ANY PARTICIPANT TO YOU OR ANY PARTY ARE PROVIDED "AS IS"
* AND WITHOUT ANY WARRANTY OF ANY KIND. AMT, MTCONNECT, AND EACH OF THEIR
* RESPECTIVE MEMBERS, OFFICERS, DIRECTORS, AFFILIATES, SPONSORS, AND AGENTS
* (COLLECTIVELY, THE "AMT PARTIES") AND PARTICIPANTS MAKE NO REPRESENTATION OR
* WARRANTY OF ANY KIND WHATSOEVER RELATING TO THESE MATERIALS, INCLUDING, WITHOUT
* LIMITATION, ANY EXPRESS OR IMPLIED WARRANTY OF NONINFRINGEMENT,
* MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. 

* LIMITATION OF LIABILITY. IN NO EVENT SHALL AMT, MTCONNECT, ANY OTHER AMT
* PARTY, OR ANY PARTICIPANT BE LIABLE FOR THE COST OF PROCURING SUBSTITUTE GOODS
* OR SERVICES, LOST PROFITS, LOSS OF USE, LOSS OF DATA OR ANY INCIDENTAL,
* CONSEQUENTIAL, INDIRECT, SPECIAL OR PUNITIVE DAMAGES OR OTHER DIRECT DAMAGES,
* WHETHER UNDER CONTRACT, TORT, WARRANTY OR OTHERWISE, ARISING IN ANY WAY OUT OF
* THIS AGREEMENT, USE OR INABILITY TO USE MTCONNECT MATERIALS, WHETHER OR NOT
* SUCH PARTY HAD ADVANCE NOTICE OF THE POSSIBILITY OF SUCH DAMAGES.
*/

#include "internal.hpp"
#include "haas_adapter.hpp"
#include "server.hpp"
#include "string_buffer.hpp"
#include "config_trida.h"
#include "logger.hpp"


char* _buffer_soubor_actual = NULL;
size_t _buffer_soubor_delka = 0;

int nacti_adaptery();
bool kontrola_zmeny_seznamu_adapteru();
int uvolni_adaptery();
void spust_adaptery();


int main()
{
  /* Construct the adapter and start the server */

  
  gLogger = new Logger();
    int i = 0;
   for(;;)
    {   
        if(kontrola_zmeny_seznamu_adapteru())
        {
            uvolni_adaptery();
            sleep(2);
            if(nacti_adaptery() != 0)
            continue;
            spust_adaptery();
            sleep(5);
            i=0;
        }
        sleep(2);
        i++;
    }
    uvolni_adaptery();
    
    return 0;

}

int nacti_adaptery()
{
    config_trida cnfg(CESTA_CONFIG);
    if(cnfg.proces()!=0)
    {
        gLogger->error("chyba config souboru");
        return -1;
    }
    return 0; 
}


bool kontrola_zmeny_seznamu_adapteru()
{
    bool zmena = false;
    char* pom_buffer;
    int pocet_pokusu = 0;
    bool nalezeno = false;
    FILE* soubor;

   DALSIPOKUS: 
    while (!nalezeno)
    {
        if(pocet_pokusu > 8)
        {
             gLogger->error("soubor adapteru nenalezen");
             exit(1);
        }
        soubor = fopen(CESTA_CONFIG,"r");
        if(soubor == NULL)
        {
            gLogger->info("pokus o otevreni config souboru");
            pocet_pokusu++;
            sleep(1);
        }
        else
        {
            nalezeno = true;
        }       
    }
    
    fseek(soubor,0,SEEK_END);
    size_t velikost = ftell(soubor);
    if(velikost == 0)
    {
        gLogger->error("velikost config soubor nula");
        fclose(soubor);
        pocet_pokusu++;
        sleep(1);
        nalezeno = false;
        goto DALSIPOKUS;
    }
    fseek(soubor,0,SEEK_SET);
    pom_buffer = (char*)malloc(velikost);
    size_t nacteno = fread(pom_buffer,velikost,1,soubor);
    if(nacteno != 1)
        {
          gLogger->error("chyba cteni vstupniho souboru");
          fclose(soubor);
          exit(1);
        }
    fclose(soubor);
    if(_buffer_soubor_actual == NULL)
    zmena = true;
    else
    {
        if(velikost != _buffer_soubor_delka)
        zmena = true;
        else
        {
            if(memcmp(pom_buffer,_buffer_soubor_actual,velikost)!= 0)
            zmena = true;
        }
    }
    
    if(!zmena)
    {
        free(pom_buffer);
        return false;
    }

    if(_buffer_soubor_actual != NULL)
    free(_buffer_soubor_actual);

    _buffer_soubor_actual = pom_buffer;
    _buffer_soubor_delka = velikost;

    return true;
}


int uvolni_adaptery()
{
   for(size_t i = 0; i<_adaptery.size();i++)
    {
        delete(_adaptery.at(i));
    }
    _adaptery.clear();  
    return 0;
}

void spust_adaptery()
{
 for(int i = 0;i<_adaptery.size();i++)
  {
    
    _adaptery.at(i)->startMichalServer();

  }
}