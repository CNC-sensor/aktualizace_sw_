
#include "internal.hpp"
#include "config_trida.h"
#include "haas_adapter.hpp"
#include "logger.hpp"


	
config_trida::config_trida(const char* cesta)
{
    FILE* soubor = fopen(cesta,"r");
    if(soubor == NULL)
    {
		gLogger->error("nepodarilo se otevrit config_json soubor");
		exit(1);
	}

    fseek(soubor,0,SEEK_END);
    size_t velikost = ftell(soubor);
    if(velikost == 0)
    {
    	gLogger->error("velikost soubor nula");
		exit(1);
    }
    fseek(soubor,0,SEEK_SET);
    pom_buffer = (char*)malloc(velikost);
    size_t nacteno = fread(pom_buffer,velikost,1,soubor);
    if(nacteno != 1)
    {
		gLogger->error("chyba cteni vstupniho souboru");
		exit(1);
	}
    fclose(soubor);
}

int config_trida::proces()
{
    int port = 7878;
	char* pom_text;
    rapidjson::Document dokument;
	rapidjson::ParseResult ok = dokument.Parse<rapidjson::kParseStopWhenDoneFlag>(pom_buffer);
	if (!ok)
	{
		//printf("buffer: %s",pom_buffer);
		//printf("chyba parser %s",rapidjson::GetParseError_En(ok.Code()));
		gLogger->error("JSON parse error");
		return -1;
	}
	rapidjson::Value::ConstMemberIterator cmi = dokument.FindMember("machines");
	if (cmi == dokument.MemberEnd())
	{
		gLogger->error("nenalezeno config_soubor machines\n");
		return -1;
	}
	rapidjson::Value& machines = dokument["machines"];

	for (rapidjson::Value::ConstValueIterator itr3 = machines.Begin(); itr3 != machines.End(); ++itr3)
	//Value::ConstValueIterator itr3 = machines.Begin();
	{
        const rapidjson::Value& data = *itr3;
		rapidjson::Value::ConstMemberIterator itr4;
       
	   HaasAdapter* pom_adapter = new HaasAdapter(port);

        /////////////////////////////////////////////////////////////////////////////////
		itr4 = data.FindMember("machine_name");
		if (itr4 == data.MemberEnd())
		{
			delete pom_adapter;
			return -1;
		}
		if (itr4->value.IsNull() == true)//test jesli je hodnota dostupna.....nejsem si jist
		{
			delete pom_adapter;
			return -1;
		}
		if(itr4->value.IsString())
			{
			//puts((char*)itr4->value.GetString());
			pom_adapter->vMachineName = (char*)itr4->value.GetString();
			}
			else
			{
				gLogger->error("chyba parsovani vstupnich hodnot - jmeno_stroje");
				delete pom_adapter;
				return -1;
			}
		////////////////////////////////////////////////////////////////////////
		
		/*itr4 = data.FindMember("ip_address");
		if (itr4 == data.MemberEnd())
		{
            delete pom_adapter;
			return -1;
		}
		if(itr4->value.IsString())
			{
				pom_text = (char*)itr4->value.GetString();
			}
			else
			{
                delete pom_adapter;
                gLogger->error("chyba parsovani vstupnich hodnot - adresa");
				return -1;
			}

		if (itr4->value.IsNull() == true)//test jesli je hodnota dostupna.....nejsem si jist
		{
			delete pom_adapter;
			return -1;
		}
		pom_text = (char*)itr4->value.GetString();
		if (pom_text == NULL)
		{
            delete pom_adapter;
			return -1;
		}
        pom_adapter->vIpAddr = pom_text;

		*/
		///////////////////////////////////////////////////////////////////
		itr4 = data.FindMember("com");
		if (itr4 == data.MemberEnd())
		{
            delete pom_adapter;
			return -1;
		}
		if (itr4->value.IsNull() == true)//test jesli je hodnota dostupna.....nejsem si jist
		{
            delete pom_adapter;
			return -1;
		}
		if(itr4->value.IsInt())
			{
				pom_adapter->vCom = itr4->value.GetInt();
			}
			else
			{
                delete pom_adapter;
                gLogger->error("chyba parsovani vstupnich hodnot - Com");
				return -1;
			}	
		///////////////////////////////////////////////////////////////////

		itr4 = data.FindMember("baud");
		if (itr4 == data.MemberEnd())
		{
            delete pom_adapter;
			return -1;
		}
		if (itr4->value.IsNull() == true)//test jesli je hodnota dostupna.....nejsem si jist
		{
            delete pom_adapter;
			return -1;
		}
		if(itr4->value.IsInt())
			{
				pom_adapter->vBaud = itr4->value.GetInt();
			}
			else
			{
                delete pom_adapter;
                gLogger->error("chyba parsovani vstupnich hodnot - Com");
				return -1;
			}	


		///////////////////////////////////////////////////////////////////////

		itr4 = data.FindMember("parity");
		if (itr4 == data.MemberEnd())
		{
            delete pom_adapter;
			return -1;
		}
		if(itr4->value.IsString())
			{
				pom_text = (char*)itr4->value.GetString();
			}
			else
			{
                delete pom_adapter;
                gLogger->error("chyba parsovani vstupnich hodnot - parity");
				return -1;
			}

		if (itr4->value.IsNull() == true)//test jesli je hodnota dostupna.....nejsem si jist
		{
			return -1;
		}
		pom_text = (char*)itr4->value.GetString();
		if (pom_text == NULL)
		{
            delete pom_adapter;
			return -1;
		}
        pom_adapter->vParity = pom_text;

		///////////////////////////////////////////////////////////////////

		itr4 = data.FindMember("dataBit");
		if (itr4 == data.MemberEnd())
		{
            delete pom_adapter;
			return -1;
		}
		if (itr4->value.IsNull() == true)//test jesli je hodnota dostupna.....nejsem si jist
		{
            delete pom_adapter;
			return -1;
		}
		if(itr4->value.IsInt())
			{
				pom_adapter->vDataBit = itr4->value.GetInt();
			}
			else
			{
                delete pom_adapter;
                gLogger->error("chyba parsovani vstupnich hodnot - DataBit");
				return -1;
			}	
		///////////////////////////////////////////////////////////////////

		itr4 = data.FindMember("stopBit");
		if (itr4 == data.MemberEnd())
		{
            delete pom_adapter;
			return -1;
		}
		if (itr4->value.IsNull() == true)//test jesli je hodnota dostupna.....nejsem si jist
		{
            delete pom_adapter;
			return -1;
		}
		if(itr4->value.IsInt())
			{
				pom_adapter->vStopBit = itr4->value.GetInt();
			}
			else
			{
                delete pom_adapter;
                gLogger->error("chyba parsovani vstupnich hodnot - StopBit");
				return -1;
			}	

		pom_adapter->initialize();
        _adaptery.push_back(pom_adapter);
		port++;

    }

	return 0;
}


config_trida::~config_trida()
{
    free (pom_buffer);
}
