
#include "internal.hpp"
#include "haas_ethernet.hpp"
#include "logger.hpp"


// zatim nepotrebne, pac starsi sysytemy Haas neumeji Q codes skrze ethernet


using namespace std;

HaasEthernet::HaasEthernet (const char *aDevice, const char *IP_addr,int port)
{
    _Device = *aDevice;
    _IP_addr = *IP_addr;
    _port = port;

}

int HaasEthernet::connect_ethernet()
{
if(_IP_addr == "" || _port == 0) {
        std::cout << "Missing Host and Port" << std::endl;
		close_ethernet();
		return -1;
    } else {
        std::cout << "Found Proper Host " << _IP_addr << " and Port " <<_port <<std::endl;
    }

	//sockaddr_in _server;


	_socket = socket(AF_INET, SOCK_STREAM, 0);
	if (_socket == -1) 
	{
		std::cout << "Error Opening Socket" << std::endl;
		close_ethernet();
		return -1;
	}
	else 
	{
		std::cout << "Socket Opened Successfully" << std::endl;
	}

	
	_server.sin_port = htons(_port);            
	_server.sin_family = AF_INET;
	if (inet_pton(AF_INET, _IP_addr.c_str(), &_server.sin_addr) < 0)
		{
            gLogger->error("Chyba fce inet_pton");
            return -1;
        }

	
	if (connect(_socket, (sockaddr*)&_server, sizeof(_server)) != 0) 
	{
		printf("Connection error %s\n", _IP_addr.c_str());
		close_ethernet();
		return -1;
	}
	printf("Connected on %s\n",_IP_addr.c_str());
	_connected = true;
	return 0;

}

int HaasEthernet::close_ethernet()

{
	_connected = false;
   if(close(_socket) == -1)
	   {
           gLogger->error("Chyba fce Ethernet_close");
           return -1;
      }
	return 0;
}




int HaasEthernet::sendCommand(const char *aCommand,std::vector<std::string>** vecOut)
{
  // Wait a small amount of time.
  usleep(20 * 1000); // 20 msec
  
  char buffer[1024];
  sprintf(buffer, "%s\r\n", aCommand);
  // doplnit o test
  
  int ret = write(buffer);

  int retRead = readUntil("\r\n>", buffer, sizeof(buffer));
  if (retRead == 0)
    return -1;
    else if(retRead == -1)
    return -1;
    else if(retRead == -2)
    return -2;
    else if(retRead == -3)
    return -3;
   
  // Find STX for the beginning start of data
  char *cp = buffer;
  while (*cp != 0x02 && *cp)
    cp++;

  if (*cp == 0)
    return -1;
  
  cp++;

  *vecOut = split(cp);
  return 0;
}

bool HaasEthernet::getVariable(int aVariableNumber, double &aResult)
{
  char command[64];
  int ret;
  vector<string>* pVec = NULL;
  bool again = false;
  do 
  {
    sprintf(command, "Q600 %d", aVariableNumber);
    ret = this->sendCommand(command,&pVec);
    if(ret < 0 )
    return false;    
    printf("%s\n",pVec->at(2).c_str());
    if (pVec && pVec->size() == 3)
    {
      // Check to make sure the correct variable is received
      if (atoi(pVec->at(1).c_str()) == aVariableNumber)
      {
	string &v = pVec->back();
	aResult = atof(v.c_str());
      }
      else if (!again)
      {
	//  we'll try a second time after flushing the input stream.
	again = true;

      }
      else // Only try twice.
	again = false;
    }
    if (pVec)
      delete pVec;

    
  } while (again);

  return true;
}



