#pragma once

class config_trida
{
public:
	config_trida(const char*);
	int proces();
	char* pom_buffer;
	~config_trida();
};
