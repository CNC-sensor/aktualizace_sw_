make clean

