/*
* Copyright (c) 2008, AMT – The Association For Manufacturing Technology (“AMT”)
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*     * Redistributions of source code must retain the above copyright
*       notice, this list of conditions and the following disclaimer.
*     * Redistributions in binary form must reproduce the above copyright
*       notice, this list of conditions and the following disclaimer in the
*       documentation and/or other materials provided with the distribution.
*     * Neither the name of the AMT nor the
*       names of its contributors may be used to endorse or promote products
*       derived from this software without specific prior written permission.
*
* DISCLAIMER OF WARRANTY. ALL MTCONNECT MATERIALS AND SPECIFICATIONS PROVIDED
* BY AMT, MTCONNECT OR ANY PARTICIPANT TO YOU OR ANY PARTY ARE PROVIDED "AS IS"
* AND WITHOUT ANY WARRANTY OF ANY KIND. AMT, MTCONNECT, AND EACH OF THEIR
* RESPECTIVE MEMBERS, OFFICERS, DIRECTORS, AFFILIATES, SPONSORS, AND AGENTS
* (COLLECTIVELY, THE "AMT PARTIES") AND PARTICIPANTS MAKE NO REPRESENTATION OR
* WARRANTY OF ANY KIND WHATSOEVER RELATING TO THESE MATERIALS, INCLUDING, WITHOUT
* LIMITATION, ANY EXPRESS OR IMPLIED WARRANTY OF NONINFRINGEMENT,
* MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. 

* LIMITATION OF LIABILITY. IN NO EVENT SHALL AMT, MTCONNECT, ANY OTHER AMT
* PARTY, OR ANY PARTICIPANT BE LIABLE FOR THE COST OF PROCURING SUBSTITUTE GOODS
* OR SERVICES, LOST PROFITS, LOSS OF USE, LOSS OF DATA OR ANY INCIDENTAL,
* CONSEQUENTIAL, INDIRECT, SPECIAL OR PUNITIVE DAMAGES OR OTHER DIRECT DAMAGES,
* WHETHER UNDER CONTRACT, TORT, WARRANTY OR OTHERWISE, ARISING IN ANY WAY OUT OF
* THIS AGREEMENT, USE OR INABILITY TO USE MTCONNECT MATERIALS, WHETHER OR NOT
* SUCH PARTY HAD ADVANCE NOTICE OF THE POSSIBILITY OF SUCH DAMAGES.
*/

#include "internal.hpp"
#include "haas_adapter.hpp"
#include "config_trida.h"
#include "logger.hpp"

using namespace std;

std::vector<HaasAdapter*> _adaptery;
std::string pomProgramComment;


HaasAdapter::HaasAdapter(int aPort)
  : Adapter(aPort, 1000), 
    mZeroRet("servo"), mMessage("message"), mExecution("execution"),
    mXact("Xact"), mYact("Yact"), mZact("Zact"), 
    mSpindleSpeed("spindle_speed"), 
    mProgram("program"), mProgramComment("programComment"),mMode("mode"), 
    mPartCount("part_count"), mEstop("estop"), mSystem("system"),
    mAvail("avail"), mPositions(true),mTool("tool_id"),mSpindleOverride("Sovr"),mFeedOverride("Fovr")
{
  //printf("konstruktor haas_adapter = %d\n",mPort);
  addDatum(mMessage);
  addDatum(mSystem);
  addDatum(mZeroRet);
  addDatum(mSystem);
  addDatum(mExecution);
  addDatum(mXact);
  addDatum(mYact);
  addDatum(mZact);
  addDatum(mSpindleSpeed);
  addDatum(mProgram);
  addDatum(mProgramComment);
  addDatum(mMode);
  addDatum(mPartCount);
  addDatum(mEstop);
  addDatum(mAvail);
  addDatum(mTool);
  addDatum(mSpindleOverride);
  addDatum(mFeedOverride);

  mErrorString[0] = 0;

}

void HaasAdapter::initialize()
{
  
  /* Construct the adapter and start the server */
  //mSerial = new HaasSerial(aArgv[i], 115200, "none", 8, 1);
  
  if(mSerial == NULL)
  {
    mSerial = new HaasSerial(vMachineName.c_str(),vBaud, vParity.c_str(), vDataBit, vStopBit);//zmenit pro kazdou instalaci
    //printf("zalozen serial %s\n",vMachineName.c_str());
  }
  //mSerial = new HaasSerial(vDevice.c_str(),vBaud, vParity.c_str(), vDataBit, vStopBit);

}

void HaasAdapter::start()
{
  startServer();
}

void HaasAdapter::stop()
{
  stopServer();
}

bool HaasAdapter::connect()
{
  bool ret = mSerial->connect();
  if (ret)
  {
    mSerial->flushInput();
  }
  
  return ret;    
}

void HaasAdapter::disconnect()
{
  mSerial->disconnect(); 
  unavailable();
}

void HaasAdapter::actual()
{
  double result;

  if (mSerial->getVariable(5041, result))//5041
  {
    mBuffer.timestamp();
    mXact.setValue(result);
    flush();
  }
  
  if (mSerial->getVariable(5042, result))
  {
    mBuffer.timestamp();
    mYact.setValue(result);
    flush();
  }

  if (mSerial->getVariable(5043, result))
  {
    mBuffer.timestamp();
    mZact.setValue(result);
    flush();
  }
  ///////////////////////////pridani overridu vretene a pracovniho posuvu////////////////////////
  if (mSerial->getVariable(1146, result))
  {
    mBuffer.timestamp();
    if(result == 1)
    {
      mSpindleOverride.setValue(-1);// hodnota overridu kdyz neni nastaveno na stroji 100%
      flush();
    }
    else
    {
      mSpindleOverride.setValue(100);
      flush();
    }
  }
  if (mSerial->getVariable(1145, result))
  {
    mBuffer.timestamp();
    if(result == 1)
    {
      mFeedOverride.setValue(-1);// hodnota overridu kdyz neni nastaveno na stroji 100%
      flush();
    }
    else
    {
      mFeedOverride.setValue(100);
      flush();
    }
  }

}

void HaasAdapter::commanded()
{
}

void HaasAdapter::spindle()
{
  double result;
  if (mSerial->getVariable(3027, result))
  {
    mBuffer.timestamp();
    mSpindleSpeed.setValue(result);
    flush();
  }
}

void HaasAdapter::feedrate()
{
  
}

void HaasAdapter::execution()
{
  vector<string>* pVec = NULL;
  
  pVec = mSerial->sendCommand("Q104");
  if (pVec && pVec->size() > 1)
  {
    string &mode = pVec->at(1);
    if (mode == "MDI")
      mMode.setValue(ControllerMode::eMANUAL_DATA_INPUT);
    else if (mode == "JOG" || mode == "ZERORET")
      mMode.setValue(ControllerMode::eMANUAL);
    else 
      mMode.setValue(ControllerMode::eAUTOMATIC);

    if (mode == "ZERORET")
    {
        mZeroRet.mActiveList[0]->setValue(Condition::eFAULT, "NO ZERO X");
    }
    else
    {
        mZeroRet.mActiveList[0]->setValue(Condition::eNORMAL);
    } 
  }

  if (pVec)
    {
        delete pVec;
        pVec = NULL;  
    }

  pVec = mSerial->sendCommand("Q500");
  if (pVec && pVec->size() > 1)
  {
    string first = pVec->at(0);
    string second = pVec->at(1);

    if (first == "PROGRAM")
    {
      if (second != "MDI")
        {
          if(strcmp(second.c_str(),mProgram.getValue())!= 0)
          mProgramToFile((char*)second.c_str());
          mProgram.setValue(second.c_str());
        }
      
        string third = pVec->at(2);
      if (third == "IDLE")
        mExecution.setValue(Execution::eREADY);
      else if (third == "FEED HOLD")
        mExecution.setValue(Execution::eINTERRUPTED);
      
      if (third == "ALARM ON")
      {
        mExecution.setValue(Execution::eSTOPPED);
        double result;
        if (mSerial->getVariable(1007, result))
        {
          if (result > 0.0)
            mEstop.setValue(EmergencyStop::eTRIGGERED);
          else
            mEstop.setValue(EmergencyStop::eARMED);
        }
        
        mSystem.mActiveList[0]->setValue(Condition::eFAULT, "Alarm on indicator");
      }
      else
      {
        mEstop.setValue(EmergencyStop::eARMED);
        mSystem.mActiveList[0]->setValue(Condition::eNORMAL);
      }
      
      if (pVec->at(3) == "PARTS")
        mPartCount.setValue(atoi(pVec->at(4).c_str()));
    }
    
    if (first == "STATUS" && second == "BUSY")
    {
        mExecution.setValue(Execution::eACTIVE);
        if(strcmp(mProgram.getValue(),"UNAVAILABLE") == 0 || strcmp(mProgram.getValue(),"") == 0)
        {
          char pomBuff[255];
          mProgramToRead(pomBuff);
          mProgram.setValue(pomBuff);  
        }
        if(mEstop.getValue() == EmergencyStop::eUNAVAILABLE)
        {
          mEstop.setValue(EmergencyStop::eARMED);  
        }
    }
  }
////////////////////////////////////////////////////////////////////////////////
//uprava michal 14.12.2021
  if (pVec)
  {
    delete pVec;
    pVec = NULL;
  }

  pVec = mSerial->sendCommand("Q201");
  if (pVec && pVec->size() > 1)
  {
    int tool = atoi(pVec->at(1).c_str());
    mTool.setValue(tool);
  }
  //uprava michal 3.7.2022
  mProgramComment.setValue(pomProgramComment.c_str());

  ///////////////////////////////////////////////////////////////////////////////
  if (pVec)
  {
    delete pVec;
  }
  flush();
}

HaasAdapter::~HaasAdapter()
{
  //printf("destruktor HaasAdapter::~HaasAdapter = %d\n",mPort);
  if(mSerial != NULL)
  { 
    disconnect();
    stopMichalServer();//uprava Michal
    delete mSerial;
  }
}

void HaasAdapter::gatherDeviceData()
{
  try
  {

    int ret;
    std::vector<std::string>* pVec = NULL;

    if (!mSerial->connected())
    {
      if (!connect())
        sleep(5);
    }
    else
    {
      mSerial->flushInput();  

      // Test connection and make sure we're synched before we start
     pVec = mSerial->sendCommand("Q100");
     if (pVec && pVec->size() == 2 && pVec->front() == "S/N")
      {
        delete pVec;
        flush();
        mAvail.available();
        if (mPositions)
          actual();
          commanded();
          spindle();
          execution();
      }
      else
      {
        delete pVec;
        disconnect();
      }
    }
  }
  
  catch (Serial::SerialError &e)
  {
    gLogger->error("SerialError: %s\n", e.message());
    disconnect();
  }
  
}

void HaasAdapter::mProgramToFile(char* program)
{
  
  char buff[255];
  FILE* soubor;
  soubor = fopen(getmProgramFileName().c_str(),"w+");
  if(soubor == NULL)
  {
    gLogger->error("Can't open mProgramToFile");
    return;
  }
  sprintf(buff,"%s",program);
  fwrite(buff,sizeof(char),strlen(buff)+1,soubor);
  if(soubor != NULL)
  fclose(soubor);
}

void HaasAdapter::mProgramToRead(char* program)
{
  
  //char buff[255];
  FILE* soubor;
  size_t len;
  soubor = fopen(getmProgramFileName().c_str(),"r");
   if(soubor == NULL)
  {
    gLogger->error("Can't open mProgramToRead");
    return;
  }
  fseek (soubor , 0 , SEEK_END);
  len = ftell(soubor);
  fseek (soubor,0,SEEK_SET);
  size_t pocet = fread(program,len,1,soubor);
  if(pocet != 1)
  {
    gLogger->error("Error in read mProgram file");
  }
  if(soubor != NULL)
  fclose(soubor);
}


std::string HaasAdapter::getmProgramFileName()
{
  return CESTA_mPROGRAM + to_string(mPort) + ".txt";
}

void HaasAdapter::startMichalServer()
{
   int ret = pthread_create(&vlakno_server,0,thread_server,this);
}

void HaasAdapter::stopMichalServer()
{
   void* ret_val;
   stopServer();
   if(vlakno_server!=0)
    {
        if(pthread_join(vlakno_server,&ret_val)!=0)
        {
            vlakno_server = 0;
            gLogger->error("error pthread_join server");    
        }
        vlakno_server = 0;
    }
}


void* HaasAdapter::thread_server(void* param)
{
  HaasAdapter* pom_adapter = (HaasAdapter*)param;
   //printf("zacatek thread_server %d\n",pom_adapter->vlakno_server);
  pom_adapter->startServer();
  //printf("konec thread_server %d\n",pom_adapter->vlakno_server);
  return NULL;
}