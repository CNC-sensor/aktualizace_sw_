
#include "internal.hpp"
#include "haas_adapter.hpp"
#include "serial.hpp"
#include "logger.hpp"

#include <stdio.h>

Serial::SerialError::SerialError(const char *aMessage)
{
  strncpy(mMessage, aMessage, 1023);
  mMessage[1023] = '\0';
  
}

Serial::Serial(const char *aDevice,
	       int aBaud, const char *aParity, int aDataBit,
	       int aStopBit)
{
  mBaud = aBaud;
  strncpy(mDevice, aDevice, sizeof(mDevice) - 1);
  mParity[sizeof(mDevice) - 1] = '\0';
  strncpy(mParity, aParity, sizeof(mParity) - 1);
  mParity[sizeof(mParity) - 1] = '\0';
  mDataBit = aDataBit;
  mStopBit = aStopBit;
  mFlow = eNONE;

#ifdef WIN32
  mFd = INVALID_HANDLE_VALUE;
#else
  mFd = -1;
#endif

  mConnected = false;
}

Serial::~Serial()
{
  
}

int Serial::readUntil(const char *aUntil, char *aBuffer, int aLength)
{
  if (!mConnected)
  {
    gLogger->error("Trying to read when not connected");
    return -1;
  }
    
  gLogger->debug("Reading upto %d bytes or '%c' we get a match", aLength, aUntil);

  int len = 0, count = 0;
  char *cp = aBuffer;
  const char *match = aUntil;

  do
  {
    usleep(1000);
    
    int ret = read(cp, 1);

    if (ret == -1)
    {
      gLogger->error("Read function failed");
      throw SerialError("Couldn't read");  
    }

    if (ret == 0)
    {
      usleep(10 * 1000); // 10 msec
      if (count++ > 10)
      {
	    gLogger->info("Read timed out\n");
	    len = 0;
      break;
      //return -1;// tady je asi chyba pac tim returnem to nevypadne ze smycky
      }
    }
    else
    {
      count = 0;
      //printf("Received: znak %c,(%d) == match: %d\n", *cp,*cp, *match); 
      if (*match == *cp)
	match++;
      else
	match = aUntil;

      // See if we can match the beginnig of the string again.
      if (*match == *cp)
	match++;
      //printf("Match now: %d\n", *match);
      cp++;
      len++;
    }
  } while (len <= aLength && *match != '\0');

  *cp = '\0';

  gLogger->debug("Read returned: %d - '%s'", len, aBuffer);

  return len;
}

int Serial::write(const char *aBuffer)
{
 // gLogger->debug("Writing '%s'\n", aBuffer);

  int ret = write(aBuffer, (int) strlen(aBuffer));
  if (ret < 0)
    throw SerialError("Couldn't write");
  
  //gLogger->debug("Write returned: %d\n", ret);
  if (ret == 0)
    throw SerialError("None data returned");
  
  if(ret < strlen(aBuffer))
    throw SerialError("Serial data lost");

  return ret;
}

bool Serial::flushInput()
{
 
 char buffer[512];// uprava Michal 4.7.2022 pro nacitani jmena programu
  int ret;
  ret = read(buffer,sizeof(buffer)-1);
  


  if(ret >= sizeof(buffer)-21)
    {
      tcflush(mFd,TCIFLUSH);
      throw SerialError("Bigger ret than default buffer");
    }
  if(ret < 0)
    throw SerialError ("Read error");
  if(ret == 0)
  {
    return true;
  }
  buffer[ret] = '\0';
  char* pText = strstr(buffer,"-+"); // fce hleda zacatek nazvu programu, ktery je detekovan znaky (-+) tj. -+NAZEV_Programu+-
  if(pText != NULL)
  {
    pText = pText+2;
    char* pKonec = strstr(pText,"+-");
    if(pKonec != NULL)
    {
      *pKonec = '\0';
      //puts(pText);
      //printf("flushInput naslo %s o poctu znaku %d\n",buffer,ret);
      pomProgramComment = pText;
      tcflush(mFd, TCIFLUSH);
      return true;
    }

    pKonec = &(buffer[ret]);
    int pokus = 0;
    bool nalezeno = false;
    while(pokus < 20)
    {
      read(pKonec,1); // asi neni potreba kontrola
      char* pPom = strstr(pText,"+-\r\n"); 
      if(pPom != NULL)
      {
        pKonec = pKonec-3;
        nalezeno = true;
        break;
      }
      pKonec++;
      pokus++;
    }
    if(nalezeno)
    {
      *pKonec = '\0';
      pomProgramComment = pText;
    }
    //printf("flushInput nenaslo %s o poctu znaku %d\n",buffer,ret);
    tcflush(mFd,TCIFLUSH);
    return true;
  }
  tcflush(mFd, TCIFLUSH);
  return true;
}

int Serial::readFully(char *aBuffer, int len, uint32_t timeout)
{
  int consumed = 0;
  uint64_t start = getTimestamp();
  while (consumed < len && (getTimestamp() - start) < timeout) {
    int res = wait(100);
    if (res > 0) {
      int cnt = read(aBuffer + consumed, len - consumed);
      if (cnt < 0) {
        gLogger->debug("Read returned: %d\n", res);
        return -1;
      }
      consumed += cnt;
    } else if (res < 0) {
      gLogger->debug("Wait returned: %d\n", res);
      return res;
    }
  }
  
  return consumed;
}

int Serial::writeFully(const char *aBuffer, int len, uint32_t timeout)
{
  int written = 0;
  
  uint64_t start = getTimestamp();
  while (written < len && (getTimestamp() - start) < timeout) {
    int res = wait(100, Serial::WRITE);
    if (res > 0) {
      int cnt = write(aBuffer + written, len - written);
      if (cnt > 0) {
        written += cnt;
      } else {
        gLogger->debug("Write returned: %d\n", res);
        return -1;
      }
    } else if (res < 0) {
      gLogger->debug("Wait returned: %d\n", res);
      return res;
    }
  }  
  
  return written;
}

#ifdef WIN32
#include "serial.win32.inc"
#else
#include "serial.unix.inc"
#endif

