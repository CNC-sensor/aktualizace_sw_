
#ifndef LOGGER_HPP
#define LOGGER_HPP

#include <stdarg.h>
#include <stdio.h>
#include <time.h>

#define LOGGER_BUFFER_SIZE 1024

class Logger {
public:
  enum LogLevel {
    eDEBUG,
    eINFO,
    eWARNING,
    eERROR
  };
  
  Logger(FILE *aFile = stderr) : mFile(aFile) 
  { mLogLevel = eINFO; buffer_old_error[0]='\0'; time_old_error = 0; 
  buffer_old_warn[0]='\0';time_old_warn = 0; 
  buffer_old_info[0]='\0';time_old_info = 0;
  buffer_old_debug[0]='\n';time_old_debug = 0; }
  void setLogLevel(LogLevel aLevel) { mLogLevel = aLevel; }
  LogLevel getLogLevel() { return mLogLevel; }
  
  virtual void error(const char *aFormat, ...);
  virtual void warning(const char *aFormat, ...);
  virtual void info(const char *aFormat, ...);
  virtual void debug(const char *aFormat, ...);
  
protected:
  const char *format(char *aBuffer, int aLen, const char *aFormat, va_list args);
  const char *timestamp(char *aBuffer);
  
  char buffer_old_error[LOGGER_BUFFER_SIZE];
  time_t time_old_error;

  char buffer_old_warn[LOGGER_BUFFER_SIZE];
  time_t time_old_warn;

  char buffer_old_info[LOGGER_BUFFER_SIZE];
  time_t time_old_info;

  char buffer_old_debug[LOGGER_BUFFER_SIZE];
  time_t time_old_debug;

  LogLevel mLogLevel;
  FILE *mFile;
};

extern Logger *gLogger;

#endif
