
#include "internal.hpp"
#include "logger.hpp"

Logger *gLogger = NULL;

void Logger::error(const char *aFormat, ...)
{
  char buffer[LOGGER_BUFFER_SIZE];
  char ts[32];
  va_list args;
  va_start (args, aFormat);
    if(strcmp(buffer_old_error,aFormat)== 0)
    {
        if(time(NULL)-time_old_error > 3600)
        {
            fprintf(mFile, "%s - Error: %s\n", timestamp(ts), format(buffer, LOGGER_BUFFER_SIZE, aFormat, args));
            fflush(mFile);
            va_end (args);
            time_old_error = time(NULL);
        }
    }
    else
    {
            fprintf(mFile, "%s - Error: %s\n", timestamp(ts), format(buffer, LOGGER_BUFFER_SIZE, aFormat, args));
            fflush(mFile);
            va_end (args);
            strcpy(buffer_old_error,aFormat);
            time_old_error = time(NULL);
    }
}

void Logger::warning(const char *aFormat, ...)
{
  if (mLogLevel > eWARNING) return;
  
  char buffer[LOGGER_BUFFER_SIZE];
  char ts[32];
  va_list args;
  va_start (args, aFormat);
      if(strcmp(buffer_old_warn,aFormat)== 0)
    {
        if(time(NULL)-time_old_warn > 3600)
        {
            fprintf(mFile, "%s - Warning: %s\n", timestamp(ts), format(buffer, LOGGER_BUFFER_SIZE, aFormat, args));
            fflush(mFile);
            va_end (args);
            time_old_warn = time(NULL);
        }
    }
    else
    {
            fprintf(mFile, "%s - Warning: %s\n", timestamp(ts), format(buffer, LOGGER_BUFFER_SIZE, aFormat, args));
            fflush(mFile);
            va_end (args);
            strcpy(buffer_old_warn,aFormat);
            time_old_warn = time(NULL);
    }
}

void Logger::info(const char *aFormat, ...)
{
  if (mLogLevel > eINFO) return;
  
  char buffer[LOGGER_BUFFER_SIZE];
  char ts[32];
  va_list args;
  va_start (args, aFormat);
    if(strcmp(buffer_old_info,aFormat)== 0)
    {
        if(time(NULL)-time_old_info > 3600)
        {
            fprintf(mFile, "%s - Info: %s\n", timestamp(ts), format(buffer, LOGGER_BUFFER_SIZE, aFormat, args));
            fflush(mFile);
            va_end (args);
            time_old_info = time(NULL);
        }
    }
    else
    {
            fprintf(mFile, "%s - Info: %s\n", timestamp(ts), format(buffer, LOGGER_BUFFER_SIZE, aFormat, args));
            fflush(mFile);
            va_end (args);
            strcpy(buffer_old_info,aFormat);
            time_old_info = time(NULL);
    }
}

void Logger::debug(const char *aFormat, ...)
{
  if (mLogLevel > eDEBUG) return;
  
  char buffer[LOGGER_BUFFER_SIZE];
  char ts[32];
  va_list args;
  va_start (args, aFormat);
     if(strcmp(buffer_old_debug,aFormat)== 0)
    {
        if(time(NULL)-time_old_debug > 3600)
        {
            fprintf(mFile, "%s - Debug: %s\n", timestamp(ts), format(buffer, LOGGER_BUFFER_SIZE, aFormat, args));
            fflush(mFile);
            va_end (args);
            time_old_debug = time(NULL);
        }
    }
    else
    {
            fprintf(mFile, "%s - Debug: %s\n", timestamp(ts), format(buffer, LOGGER_BUFFER_SIZE, aFormat, args));
            fflush(mFile);
            va_end (args);
            strcpy(buffer_old_debug,aFormat);
            time_old_debug = time(NULL);
    }
}


const char *Logger::format(char *aBuffer, int aLen, const char *aFormat, va_list args)
{
  vsprintf(aBuffer, aFormat, args);
  aBuffer[aLen - 1] = '\0';
  return aBuffer;
}

const char *Logger::timestamp(char *aBuffer)
{
#ifdef WIN32
  SYSTEMTIME st;
  GetSystemTime(&st);
  sprintf(aBuffer, "%4d-%02d-%02dT%02d:%02d:%02d.%03dZ", st.wYear, st.wMonth, st.wDay, st.wHour, 
          st.wMinute, st.wSecond, st.wMilliseconds);
#else
  struct timeval tv;
  struct timezone tz;

  gettimeofday(&tv, &tz);

  strftime(aBuffer, 64, "%Y-%m-%dT%H:%M:%S", gmtime(&tv.tv_sec));
  sprintf(aBuffer + strlen(aBuffer), ".%06luZ", tv.tv_usec);
#endif
  
  return aBuffer;
}
