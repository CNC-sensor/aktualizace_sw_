
#include "internal.hpp"
#include "haas_adapter.hpp"
#include "haas_serial.hpp"

using namespace std;

HaasSerial::HaasSerial(const char *aDevice,
	     int aBaud, const char *aParity, int aDataBit,
	     int aStopBit, bool aDebug)
  : Serial(aDevice, aBaud, aParity, aDataBit, aStopBit)
{
}

vector<string> *HaasSerial::split(const char *aString)
{
  vector<string> *list = new vector<string>;

  const char *start = aString;
  const char *cp = aString;
  
  while (*cp)
  {
    if (*cp == ',' || *cp == 0x17)
    {
      const char *end = cp;
      while (end > start && (*end == ' '))
	end--;

      if (end > start)
      {
	string s(start, end);
	list->push_back(s);
      }

      // Strip , and spaces from end of string
      while (*cp != 0x17 && (*cp == ' ' || *cp == ','))
	cp++;

      // Start parsing the next block
      start = cp;
    }
    
    if (*cp == 0x17)
      break;
    
    cp++;
  }

  return list;
}

 vector<string>* HaasSerial::sendCommand(const char *aCommand)
{
  // Wait a small amount of time.
  usleep(20 * 1000); // 20 msec
  
  char buffer[1024];
  sprintf(buffer, "%s\r\n", aCommand);
  // doplnit o test
  
  int ret = write(buffer);
  

  int retRead = readUntil("\r\n>", buffer, sizeof(buffer));
  if (retRead <= 0)
    return NULL;

   
  // Find STX for the beginning start of data
  char *cp = buffer;
  while (*cp != 0x02 && *cp)
    cp++;

  if (*cp == 0)
    return NULL;
  
  cp++;

  vector<string>* l = split(cp);

/////////////////////////////////////////////////////////
//uprava Michal 3.7.2022
char* pText = strstr(buffer,"-+"); // fce hleda zacatek nazvu programu, ktery je detekovan znaky (-+) tj. -+NAZEV_Programu+-
if(pText != NULL)
{
  pText = pText + 2;
  char* pKonec = strstr(pText,"+-");
  if(pKonec != NULL)
  {
    *pKonec = '\0';
    pomProgramComment = pText;
    //printf("send command nasel = %s\n",pomProgramComment.c_str());
  }
}
/////////////////////////////////////////////////////////

  return l;
}

bool HaasSerial::getVariable(int aVariableNumber, double &aResult)
{
  char command[64];
  bool again = false;
  do 
  {
    sprintf(command, "Q600 %d", aVariableNumber);
    vector <string>* ret = 0;
    ret = this->sendCommand(command);
    if(ret == 0 )
    return false;    
    //printf("%s\n",pVec->at(2).c_str());
    if (ret && ret->size() == 3)
    {
      // Check to make sure the correct variable is received
      if (atoi(ret->at(1).c_str()) == aVariableNumber)
      {
	      string &v = ret->back();
	      aResult = atof(v.c_str());
        again = false;
      }
      else if (!again)
      {
	      //  we'll try a second time after flushing the input stream.
	      again = true;
	      flushInput();
      }
      else // Only try twice.
	    again = false;
    }
    if (ret)
      delete ret;

    
  } while (again);

  return true;
}



